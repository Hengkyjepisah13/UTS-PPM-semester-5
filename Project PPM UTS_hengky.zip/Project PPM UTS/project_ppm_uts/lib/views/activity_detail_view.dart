
import 'package:flutter/material.dart';

import '../viewmodels/activity_viewmodel.dart';
import 'activity_form_view.dart';

class ActivityDetailView extends StatelessWidget {
  final ActivityViewModel viewModel;
  final String activityId;

  const ActivityDetailView({
    super.key,
    required this.viewModel,
    required this.activityId,
  });

  void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: const Color(0xFF237A57),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  // RESET COUNTER
  Future<void> _resetCounter(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Reset Counter'),
          content: const Text(
            'Apakah kamu yakin ingin mengembalikan counter menjadi 0?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Ya, Reset'),
            ),
          ],
        );
      },
    );

    if (confirm == true && context.mounted) {
      viewModel.resetCounter(activityId);
      _showMessage(context, 'Counter berhasil di-reset!');
    }
  }

  // HAPUS AKTIVITAS
  Future<void> _deleteActivity(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Hapus Aktivitas'),
          content: const Text(
            'Apakah kamu yakin ingin menghapus aktivitas ini?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Batal'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );

    if (confirm == true && context.mounted) {
      viewModel.deleteActivity(activityId);

      Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Aktivitas berhasil dihapus!'),
          backgroundColor: Color(0xFF237A57),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: viewModel,
      builder: (context, child) {
        final activity = viewModel.getActivityById(activityId);

        if (activity == null) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('Detail Aktivitas'),
            ),
            body: const Center(
              child: Text('Aktivitas tidak ditemukan.'),
            ),
          );
        }

        return Scaffold(
          backgroundColor: const Color(0xFFF5F7F5),

          appBar: AppBar(
            title: const Text('Detail Aktivitas'),
            backgroundColor: Colors.white,
            elevation: 0,

            actions: [
              // ICON EDIT
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                tooltip: 'Edit Aktivitas',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ActivityFormView(
                        viewModel: viewModel,
                        activity: activity,
                      ),
                    ),
                  );
                },
              ),

              // ICON SAMPAH
              IconButton(
                icon: const Icon(
                  Icons.delete_outline,
                  color: Colors.red,
                ),
                tooltip: 'Hapus Aktivitas',
                onPressed: () => _deleteActivity(context),
              ),
            ],
          ),

          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.track_changes,
                    size: 65,
                    color: Color(0xFF237A57),
                  ),

                  const SizedBox(height: 20),

                  Text(
                    activity.name,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 35),

                  // COUNTER
                  Container(
                    width: 190,
                    height: 190,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF237A57),
                        width: 5,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${activity.counter}',
                          style: const TextStyle(
                            fontSize: 60,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF237A57),
                          ),
                        ),
                        const Text(
                          'Total Aktivitas',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 35),

                  // TOMBOL TAMBAH DAN KURANG
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton.filled(
                        onPressed: () {
                          if (activity.counter > 0) {
                            viewModel.decrementCounter(activityId);
                            _showMessage(
                              context,
                              'Counter dikurangi 1',
                            );
                          } else {
                            _showMessage(
                              context,
                              'Counter tidak boleh kurang dari 0!',
                            );
                          }
                        },
                        icon: const Icon(Icons.remove),
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          fixedSize: const Size(60, 60),
                        ),
                      ),

                      const SizedBox(width: 30),

                      IconButton.filled(
                        onPressed: () {
                          viewModel.incrementCounter(activityId);
                          _showMessage(
                            context,
                            'Counter ditambahkan 1',
                          );
                        },
                        icon: const Icon(Icons.add),
                        style: IconButton.styleFrom(
                          backgroundColor: const Color(0xFF237A57),
                          foregroundColor: Colors.white,
                          fixedSize: const Size(60, 60),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 25),

                  // RESET COUNTER
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () => _resetCounter(context),
                      icon: const Icon(Icons.refresh),
                      label: const Text('Reset Counter'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
