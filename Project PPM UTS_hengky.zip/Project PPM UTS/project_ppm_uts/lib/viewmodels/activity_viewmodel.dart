
import 'package:flutter/foundation.dart';
import '../models/activity_model.dart';
import '../repositories/activity_repository.dart';

class ActivityViewModel extends ChangeNotifier {
  final ActivityRepository _repository;

  ActivityViewModel(this._repository);

  List<ActivityModel> get activities {
    return List.unmodifiable(_repository.getAllActivities());
  }

  ActivityModel? getActivityById(String id) {
    return _repository.getActivityById(id);
  }

  void addActivity(String name) {
    final activity = ActivityModel(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name.trim(),
    );

    _repository.addActivity(activity);
    notifyListeners();
  }

  void updateActivity(String id, String newName) {
    if (newName.trim().isEmpty) return;

    _repository.updateActivity(id, newName.trim());
    notifyListeners();
  }

  void deleteActivity(String id) {
    _repository.deleteActivity(id);
    notifyListeners();
  }

  void incrementCounter(String id) {
    _repository.incrementCounter(id);
    notifyListeners();
  }

  void decrementCounter(String id) {
    final activity = getActivityById(id);

    if (activity != null && activity.counter > 0) {
      _repository.decrementCounter(id);
      notifyListeners();
    }
  }

  void resetCounter(String id) {
    _repository.resetCounter(id);
    notifyListeners();
  }
}
