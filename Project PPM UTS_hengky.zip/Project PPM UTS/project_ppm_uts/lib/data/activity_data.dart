
import '../models/activity_model.dart';

class ActivityData {
  final List<ActivityModel> _activities = [
    ActivityModel(
      id: '1',
      name: 'Membaca Buku',
      counter: 5,
    ),
    ActivityModel(
      id: '2',
      name: 'Olahraga',
      counter: 3,
    ),
    ActivityModel(
      id: '3',
      name: 'Belajar Flutter',
      counter: 8,
    ),
    ActivityModel(
      id: '4',
      name: 'Mengerjakan Tugas',
      counter: 4,
    ),
  ];

  List<ActivityModel> get activities => _activities;
}
