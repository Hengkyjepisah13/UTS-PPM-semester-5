
import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _activityData;

  ActivityRepository(this._activityData);

  List<ActivityModel> getAllActivities() {
    return _activityData.activities;
  }

  ActivityModel? getActivityById(String id) {
    try {
      return _activityData.activities.firstWhere(
        (activity) => activity.id == id,
      );
    } catch (e) {
      return null;
    }
  }

  void addActivity(ActivityModel activity) {
    _activityData.activities.add(activity);
  }

  void updateActivity(String id, String newName) {
    final activity = getActivityById(id);

    if (activity != null) {
      activity.name = newName;
    }
  }

  void deleteActivity(String id) {
    _activityData.activities.removeWhere(
      (activity) => activity.id == id,
    );
  }

  void incrementCounter(String id) {
    final activity = getActivityById(id);

    if (activity != null) {
      activity.counter++;
    }
  }

  void decrementCounter(String id) {
    final activity = getActivityById(id);

    if (activity != null && activity.counter > 0) {
      activity.counter--;
    }
  }

  void resetCounter(String id) {
    final activity = getActivityById(id);

    if (activity != null) {
      activity.counter = 0;
    }
  }
}
