
import 'package:flutter/material.dart';

import 'data/activity_data.dart';
import 'repositories/activity_repository.dart';
import 'viewmodels/activity_viewmodel.dart';
import 'views/home_view.dart';

void main() {
  final activityData = ActivityData();

  final activityRepository = ActivityRepository(
    activityData,
  );

  final activityViewModel = ActivityViewModel(
    activityRepository,
  );

  runApp(
    DailyActivityApp(
      viewModel: activityViewModel,
    ),
  );
}

class DailyActivityApp extends StatelessWidget {
  final ActivityViewModel viewModel;

  const DailyActivityApp({
    super.key,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Activity Tracker',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF237A57),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7F5),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
        ),
      ),
      home: HomeView(
        viewModel: viewModel,
      ),
    );
  }
}
